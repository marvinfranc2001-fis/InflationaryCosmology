# Study of the Starobinsky Inflationary Model Using the Cobaya Code

**Thesis / Tesis de Física — Marvin Francisco Jiménez Peñafiel**  
Universidad de Investigación de Tecnología Experimental Yachay, 2026.  
Advisor: Clara Inés Rojas Cely.

> **Status / Estado:** archivo de reconstrucción documental creado el 18-10-2026. Contiene materiales verificados a partir de la tesis y registros de trabajo, además de **ejemplos reconstruidos**. **No contiene todavía los YAML/SLURM/Python originales exportados del HPC**, porque los archivos del clúster no son accesibles desde este entorno. **No confundir ejemplos con las configuraciones finales.**

## Resumen

Comparación de tres modelos cosmológicos utilizando inferencia bayesiana: modelo fenomenológico plano ΛCDM + r, Starobinsky SR1 y Starobinsky SR2. La evaluación se realizó con **Cobaya + CLASS** y las verosimilitudes **Planck 2018** y **BICEP/Keck 2018**. Se ejecutó **MCMC** como comprobación de consistencia posterior y **PolyChord** (nested sampling) para estimar distribuciones y evidencia bayesiana; la comparación definitiva usó **nlive = 300** por modelo. Se complementó el análisis con clasificación de posteriores, ablation, PCA/UMAP, SHAP y emuladores neuronales locales de χ² con validación externa Cobaya/CLASS.

## Resultados principales reportados en la tesis

| Modelo | ln Z | Incertidumbre |
| --- | ---: | ---: |
| ΛCDM + r (referencia) | -797.3157 | 0.2742 |
| Starobinsky SR1 | -795.3275 | 0.2655 |
| Starobinsky SR2 | -794.4122 | 0.2636 |

Diferencias de evidencia (tesis, tablas 5.2–5.3): SR1 vs referencia **1.9882 ± 0.3816**, SR2 vs referencia **2.9036 ± 0.3803**, SR2 vs SR1 **0.9154 ± 0.3741**. La preferencia relativa SR2 frente a SR1 se describe como **débil**, no decisiva. La convergencia adoptada para MCMC fue **R−1 < 0.01**. El máximo desplazamiento normalizado de medias MCMC–PolyChord reportado fue **0.0763σ**.

Estas cifras son **resultados históricos reportados**, no salidas obtenidas ejecutando las plantillas incluidas aquí. La evidencia depende de priors y del conjunto EXACTO de likelihoods, nuisance, configuración y versiones.

## Organización

- [`docs/metodologia.md`](docs/metodologia.md): modelos, ecuaciones SR1/SR2, priors y datos.
- [`docs/instalacion-cluster.md`](docs/instalacion-cluster.md): instalación, SSH → SLURM → Enroot → Conda y verificaciones.
- [`docs/comandos-cluster.md`](docs/comandos-cluster.md): comandos cotidianos, monitoreo, reanudación y fallos frecuentes.
- [`docs/trazabilidad-y-originales.md`](docs/trazabilidad-y-originales.md): qué está verificado, qué fue reconstruido y dónde están los archivos originales.
- [`configs_reconstruidas/`](configs_reconstruidas/): YAML ilustrativos, **no equivalentes garantizados a los YAML finales**.
- [`modelos/`](modelos/): relaciones cosmológicas documentadas y pruebas unitarias.
- [`slurm/`](slurm/): plantilla de lote, no wrapper original de producción.
- [`scripts/importar_originales_hpc.sh`](scripts/importar_originales_hpc.sh): exporta los YAML, Python, SLURM y análisis reales desde `~/Yaml` al repositorio local.
- [`machine_learning/`](machine_learning/): inventario del análisis realizado y directorios de origen.
- [`resultados/`](resultados/): resumen histórico; NO contiene cadenas de producción.

## Prueba rápida (solo matemáticas, sin CLASS)

```bash
python -m unittest discover -s tests -v
python scripts/comprobar_reconstruccion.py
```

## Importar la fuente original desde CEDIA

Ya en el clúster, con una copia de este repositorio:

```bash
bash scripts/importar_originales_hpc.sh
# Para copiar cadenas a carpeta local ignorada por Git:
bash scripts/importar_originales_hpc.sh --resultados
```

Tras ello, revisar `originales_hpc/`, comparar contra la tesis y **solo entonces** lanzar `cobaya-run originales_hpc/.../archivo.yaml --test`. Esta exportación no se ha ejecutado por el asistente, ya que no posee acceso SSH al HPC.

## Reproducibilidad y privacidad

Los scripts **no almacenan claves**, tokens, archivos `.ssh` ni credenciales. Nunca subir `.env`, cookies, claves SSH, cadenas masivas ni datasets sujetos a licencia. Las verosimilitudes observacionales se obtienen de sus distribuidores autorizados. Mantener el repositorio **privado** hasta revisar datos, permisos y derechos de terceros.

## Citación

Jiménez Peñafiel, M. F. (2026). *Study of the Starobinsky Inflationary Model Using the Cobaya Code*. Bachelor's thesis, Yachay Tech (título y autoría según manuscrito entregado). Para el software, citar también Cobaya, CLASS, PolyChord y los datasets según sus publicaciones originales.

## Documentación externa

- [Cobaya — installation](https://cobaya.readthedocs.io/en/latest/installation.html)
- [Cobaya — CLASS](https://cobaya.readthedocs.io/en/latest/theory_class.html)
- [Cobaya — PolyChord](https://cobaya.readthedocs.io/en/latest/sampler_polychord.html)
- [PolyChordLite (licencia académica)](https://github.com/PolyChord/PolyChordLite)
