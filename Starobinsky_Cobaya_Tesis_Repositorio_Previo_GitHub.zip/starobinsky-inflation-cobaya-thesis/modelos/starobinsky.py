"""Relaciones SR1/SR2 documentadas en la tesis, independientes de Cobaya.

Este módulo es para validación matemática, **no** es el `effective.py`
original ni un plugin Theory compatible con Cobaya de forma automática.
"""
from dataclasses import dataclass
from math import log, exp

PIVOT_MPC_INV = 0.05

@dataclass(frozen=True)
class Observables:
    n_s: float
    r_005: float
    alpha_s: float

def _check_n(n_star: float) -> None:
    if n_star <= 0:
        raise ValueError('N_star debe ser positivo')

def sr1(n_star: float) -> Observables:
    _check_n(n_star)
    return Observables(
        n_s=1 - 2/n_star - 9/(2*n_star**2),
        r_005=12/n_star**2,
        alpha_s=0.0,
    )

def sr2(n_star: float) -> Observables:
    _check_n(n_star)
    return Observables(
        n_s=1 - 2/n_star - 3/(2*n_star**2),
        r_005=(12/n_star**2)*(1 - 2/n_star),
        alpha_s=-2/n_star**2 - 3/n_star**3,
    )

def primordial_scalar_power(k: float, a_s: float, n_s: float,
                            alpha_s: float = 0.0,
                            pivot: float = PIVOT_MPC_INV) -> float:
    """P_R(k) para la parametrización de potencia usada en el manuscrito."""
    if k <= 0 or a_s <= 0 or pivot <= 0:
        raise ValueError('k, A_s y k_pivot deben ser positivos')
    x = log(k/pivot)
    return exp(log(a_s) + (n_s-1)*x + 0.5*alpha_s*x*x)
