# Análisis ML complementario (inventario, código por recuperar)

La tesis utilizó modelos supervisados (regresión logística y random forest), clasificación de modelos y de samplers, ablation, permutation tests, SHAP, PCA, UMAP y emuladores neuronales locales de χ² total y por likelihood. Las evaluaciones directas Cobaya+CLASS sirvieron como verificación externa. La inferencia física y evidencia se mantuvieron basadas en evaluaciones directas, no en las redes neuronales.

Código reportado dentro de `~/Yaml/final/Datos`:

```
ml_final_tesis.py
pytorch_tesis.py
tesis_chain_utils.py
validar_emulador_cobaya.py
grafin_publicable_getdist_verde.py
ml_final/
pytorch_resultados_tesis_nuevos/
codigos_tesis_corregidos/
graficos_finales/
Resultados/
```

Los scripts fuente se recuperan con `scripts/importar_originales_hpc.sh` dentro de la cuenta HPC. Las carpetas de resultados/gráficos pesados requieren selección consciente antes de publicarse. `torch` no estaba instalado en el Conda `inflacion` de una comprobación del 11/10/2026; utilizar un entorno de ML separado y documentar las versiones antes de afirmar reproducibilidad.
