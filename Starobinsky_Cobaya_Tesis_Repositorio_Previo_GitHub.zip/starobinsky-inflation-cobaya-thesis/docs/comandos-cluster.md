# Comandos y operaciones en CEDIA/SLURM

## Acceso y entorno

```bash
# Orden: equipo local -> ssh login1 -> salloc -> ssh compute -> enroot -> conda
squeue -u "$USER"
sinfo -o '%P %a %l %D'
salloc -p cpu -n 2 -c 1 --mem=16G --time=04:00:00 --exclude=compute-0-1
# Reemplazar el nodo por el asignado
ssh compute-0-2
enroot start 'condaforge+miniforge3' /bin/bash
source ~/miniconda3/etc/profile.d/conda.sh
conda activate inflacion
export CC=mpicc FC=mpif90 F77=mpif90 F90=mpif90
export OMP_NUM_THREADS=1
export PYTHONPATH="$HOME/Yaml:${PYTHONPATH:-}"
```

## Preparar y probar los originales

```bash
cd ~/Yaml
python -c 'from effective import EffectiveStarobinsky_SR1, EffectiveStarobinsky_SR2; print("import OK")'
cobaya-run polychord_starobinsky_Nfree.yaml --test --force
# Comprobar YAML final real desde la ubicación apropiada
cd ~/Yaml/final
cobaya-run polychord_starobinsky_SR1.yaml --test
```

## Corrida por lotes (no requiere abrir Enroot manualmente)

```bash
cd ~/Yaml/final
sbatch run_polychord_SR1.slurm
sbatch run_polychord_SR1_resume.slurm  # solo si hay checkpoint válido
squeue -u "$USER" -o '%.18i %.10P %.25j %.2t %.12M %.12l %R'
scontrol show job <JOBID> | grep -E 'JobState|RunTime|TimeLimit|NodeList|Reason'
tail -n 100 SR1_300_<JOBID>.out
tail -n 80 SR1_300_<JOBID>.err
```

La variante `run_polychord_SR2_MPI_seguro.slurm` se documentó bajo otra cuenta participante. **No se incluye su contenido original**, y no debe lanzarse sin recuperar el archivo auténtico.

## Lanzamiento MPI de prueba (solo dentro de asignación y entorno válido)

```bash
export OMP_NUM_THREADS=1
mpirun -np 8 cobaya-run /ruta/al/archivo_original.yaml --resume
```

No invocar `--resume` en cadenas incompletas o mezcladas de experimentos distintos. Revisar `output:` del YAML antes de cada envío. **No guardar cadenas solo en scratch volátil**: los wrappers históricos copiaban resultados a `$HOME` mediante `rsync`; comprobar la copia íntegra antes de terminar el job.

## Comprobar finalización y evidencias

```bash
sacct -j <JOBID> --format=JobID,JobName,State,ExitCode,Elapsed,MaxRSS
find ~/Yaml/final/chains_SR1_300 -maxdepth 2 -type f | head
# El log contiene nlive/ndead/nposterior/log(Z), pero solo utilizar log(Z) FINAL
```

Mensajes como `log(Z) ... (still evaluating)` indican **evidencia provisional**, no valor final. Job `COMPLETED` tampoco garantiza que la salida haya quedado copiada a almacenamiento persistente. Los datos finales deben comprobarse en los archivos de muestra/estadísticas.

## Errores documentados

| Síntoma | Diagnóstico / acción |
| --- | --- |
| `GLIBC_2.28 not found` en login1 | Incompatibilidad de Conda con libc del login; usar compute node + Enroot. |
| `ModuleNotFoundError` para torch/sklearn en `inflacion` | El entorno cosmológico no tenía necesariamente paquetes ML: crear entorno separado/instalarlos adecuadamente. |
| `conda` parece congelado | Verificar nodo/contendor, red, I/O del home; no reinstalar destructivamente sin respaldo. |
| `pypolychord` falla al compilar | Verificar MPI/Fortran coherentes y versión exacta. |
| Job terminó 0 pero no aparece output | Inspeccionar rutas de scratch, rutas YAML `output`, `rsync` y permisos. |
| `tail -f` no muestra progreso | Inspeccionar `squeue`, `sacct`, `.out`, `.err` y timestamps; puede no haber salida reciente. |
