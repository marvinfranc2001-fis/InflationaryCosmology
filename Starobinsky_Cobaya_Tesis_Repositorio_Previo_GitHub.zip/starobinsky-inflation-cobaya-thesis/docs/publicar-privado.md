# Publicación en GitHub (pasos que requieren autorización del propietario)

La cuenta vinculada identificada el 18/10/2026 fue `marvinfranc2001-fis`, pero el plugin no mostró **ningún repositorio ni instalación disponible**. La integración utilizada **no ofrece una operación para crear repositorios nuevos**. Por tanto, este paquete **no ha sido subido a GitHub**.

1. Entrar a https://github.com/new con la cuenta indicada y crear el repositorio `starobinsky-inflation-cobaya-thesis`, **privado**, sin inicializar README ni .gitignore (ya vienen en el ZIP).
2. En la configuración de la GitHub App asociada a ChatGPT, conceder acceso al repositorio privado recién creado. Debe aparecer entre repositorios accesibles para poder gestionarlo desde el plugin.
3. Alternativamente, descomprimir el ZIP, abrir la carpeta y ejecutar `bash scripts/publicar_git_cuando_exista_repo.sh`. Revisar cambios, realizar `git commit` y `git push -u origin main` con su propia autenticación GitHub.
4. Más adelante, en la cuenta del HPC, ejecutar `bash scripts/importar_originales_hpc.sh`; revisarlos cuidadosamente, y agregar solo archivos autorizados con `git add -f originales_hpc/<archivo-o-subcarpeta>`.

**Atención**: poner el repositorio privado primero. Los archivos originales pueden tener rutas internas, datos no públicos, software de terceros o fragmentos sensibles.
