# Pendientes para reproducción 1:1

- [ ] Recuperar `~/Yaml/effective.py` original; verificar que no hay distintas versiones entre `Yaml/` y `Yaml/def/`.
- [ ] Recuperar YAML finales **SR1, SR2 y LCDM+r**, y registrar su commit SHA.
- [ ] Recuperar wrappers SLURM de producción, particularmente manejo scratch/rsync y `--resume`.
- [ ] Recuperar `~/Yaml/final/Datos/` completo: scripts ML, gráficos seleccionados y métricas.
- [ ] Obtener `conda env export --no-builds`, `pip freeze`, versiones de CLASS y PolyChordLite desde el contenedor usado.
- [ ] Registrar checksums de cadenas/ficheros stats definitivos, excluyendo exploratorios.
- [ ] Ejecutar test de inicialización Cobaya/CLASS/Planck/BK18 con los YAML ORIGINALES.
- [ ] Revisar licencias de likelihoods/datasets, datos sensibles y permisos antes de cambiar de privado a público.
