# Instalación y acceso al clúster de CEDIA (registro reproducible)

> Se reconstruyeron las instrucciones a partir de sesiones de 2026. Los administradores pueden cambiar particiones, módulos y rutas. Ejecutar instalaciones en nodos permitidos y respetar cuotas.

## 1) Orden real de entrada (interactivo)

La secuencia utilizada fue **SSH al login → solicitar recursos con `salloc` → acceder al nodo asignado → iniciar Enroot → activar Conda**. No ejecutar tareas intensivas ni compilaciones pesadas en `login1`.

```bash
# Desde tu equipo. Usa el alias/host SSH autorizado por CEDIA:
ssh <usuario>@<host-del-cluster>

# En login1: revisar particiones/asignación disponible
sinfo -o '%P %a %l %D'
salloc -p cpu -n 2 -c 1 --mem=16G --time=04:00:00 --exclude=compute-0-1

# Ya con el job adjudicado, acceder al nodo ACTUAL asignado (ejemplo histórico: compute-0-2)
ssh compute-0-2

# Dentro del nodo de cómputo
enroot start 'condaforge+miniforge3' /bin/bash
source ~/miniconda3/etc/profile.d/conda.sh
conda activate inflacion

# Verificaciones que funcionaron en octubre de 2026
python -c 'import cobaya; print("Cobaya OK")'
python -c 'import classy; print("CLASS OK")'
python -c 'import pypolychord; print("PolyChord OK")'
```

**Notas**: `compute-0-2` es un ejemplo documentado, no un nodo que deba asumirse disponible. Una sesión antigua también usó `salloc -p cpu -n 8 -c 1 --mem=24G` y `ssh compute-0-1`. Los nombres históricos del contenedor fueron `condaforge+miniforge3` y en otro flujo `micudapersonal`; el contenedor verificado recientemente fue el primero.

## 2) Estado históricamente verificado

- login `login1` con usuario institucional; trabajo bajo `~/Yaml` y `~/Yaml/final`.
- `inflacion` en `/home/.../miniconda3/envs/inflacion`; Python 3.10.19 en una sesión documentada de octubre.
- Cobaya, `classy` y `pypolychord` importaron correctamente en `compute-0-2` con Enroot activo.
- Conda directamente en el nodo **login** falló con `GLIBC_2.28 not found` (en otra ruta, `GLIBC_2.27`). **No solucionar sobreescribiendo GLIBC del sistema**; ejecutar en el contenedor o nodo compatible.

## 3) Recreación de entorno (orientación, no copia fiel)

El archivo [`../environment/environment-sugerido.yml`](../environment/environment-sugerido.yml) enumera dependencias base y *no* constituye el `conda env export` real de producción. Para recuperar versiones originales:

```bash
source ~/miniconda3/etc/profile.d/conda.sh
conda activate inflacion
python --version
python -m pip freeze > /ruta/segura/pip-freeze-inflacion.txt
conda env export --no-builds > /ruta/segura/conda-inflacion.yml
python -c 'import cobaya, classy, pypolychord; print("OK")'
```

Para instalar desde cero (dentro de Enroot en un nodo con red/compiladores, usando un entorno aislado), se dispone de un flujo de referencia:

```bash
# Preexistente: Conda, mpicc, mpif90, gcc, gfortran disponibles
conda create -n inflacion python=3.10 -y
conda activate inflacion
export CC=mpicc FC=mpif90 F77=mpif90 F90=mpif90
python -m pip install 'numpy<3' scipy pyyaml mpi4py cobaya getdist
# CLASS según documentación Cobaya; requisitos del sistema pueden variar:
cobaya-install classy --packages-path "$HOME/cobaya_packages"
# PolyChordLite desde el repositorio propio / versión aprobada por licencia académica:
git clone https://github.com/PolyChord/PolyChordLite.git "$HOME/cobaya_packages/code/PolyChordLite"
cd "$HOME/cobaya_packages/code/PolyChordLite"
make pypolychord MPI=1
python -m pip install . --no-build-isolation
```

**Advertencia**: estas instrucciones son una receta reconstruida, no un instalador ejecutado/verificado en este turno. En marzo se documentó `make clean; python -m pip install . --no-build-isolation -v` y un error de compilación Fortran en `src/polychord/read_write.F90`; no se debe aplicar un parche especulativo sin examinar la versión exacta. Los likelihoods Planck/BK18 tienen descargas adicionales y condiciones de uso; instalar mediante Cobaya/los distribuidores autorizados y verificar las rutas.

## 4) Comprobación final

```bash
export OMP_NUM_THREADS=1
export PYTHONPATH="$HOME/Yaml:${PYTHONPATH:-}"
python -c 'from effective import EffectiveStarobinsky_SR1; print("SR1 import OK")'
python -c 'from effective import EffectiveStarobinsky_SR2; print("SR2 import OK")'
cobaya-run /ruta/a/YAML_ORIGINAL.yaml --test
```

Las dos clases se nombran tal como constaban en `effective.py`. **No vienen reconstruidas aquí como interfaz exacta de Cobaya**; deben exportarse desde el HPC con el script.
