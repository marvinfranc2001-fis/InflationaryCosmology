# Cronología y ejecución, reconstruida del historial

- **14 de marzo de 2026:** trabajo con `~/Yaml/effective.py`, pruebas importando `EffectiveStarobinsky_SR1` y `EffectiveStarobinsky_SR2`; instalación PolyChordLite y diagnóstico de la compilación Fortran. Se usó `PYTHONPATH=~/Yaml:$PYTHONPATH`.
- **Abril 2026:** configuraciones finales referenciaron `classy` con espectros escalares/tensoriales `Pk_ini_type: analytic_Pk` y k-pivot 0.05; combinaciones de Planck/BK18; PolyChord `nlive:300` y `num_repeats:25`. Es información reconstruida de registros, no archivo exacto.
- **15–17 junio de 2026:** ensayos MCMC y PolyChord, pruebas de inicialización: se validó acceso a CLASS, clik Planck y BICEP/Keck. Trabajos MPI SR1/SR2.
- **22–23 junio 2026:** completó una corrida de SR1 reanudada (job 16729), con salidas persistentes bajo `~/Yaml/final/chains_SR1_300`.
- **25 junio 2026:** se registró un job SR2 MPI (16991) en otra cuenta. Hay un caso donde el wrapper informa `exit code 0` pero la ruta scratch esperada no existía; es imprescindible inspeccionar datos finales antes de considerarlo correcto.
- **Octubre 2026:** se confirmó el flujo `salloc -> compute-0-2 -> enroot condaforge+miniforge3 -> conda activate inflacion` y que Cobaya, CLASS y PolyChord podían importarse.

Toda cifra o log provisional debe distinguirse de la evidencia final de la tesis. Revisar archivos originales al importar.
