# Trazabilidad — qué está confirmado y qué falta

## Confirmado a partir de material anterior

- Identificación de autor, título, institución, tutora: portada del manuscrito 2026.
- Fórmulas SR1/SR2, pivot, priors, likelihoods y diferencias MCMC/PolyChord: metodología de la tesis.
- Evidencias finales, intervalos y criterios: tablas de resultados y discusión de la tesis.
- Estructura de carpetas `~/Yaml`, `~/Yaml/final`, `~/Yaml/final/Datos` y nombres de los artefactos: salidas `ls` del clúster.
- Contenedor Enroot `condaforge+miniforge3`, Conda `inflacion`, validación `import cobaya/classy/pypolychord`: sesiones documentadas de octubre de 2026.

## Material **reconstruido y no validado como corrida original**

- Archivos de `configs_reconstruidas/`: son ejemplos derivados de la metodología, **no copias de `polychord_starobinsky_SR1.yaml`, `...SR2.yaml` ni de los MCMC auténticos**.
- Plantilla `slurm/TEMPLATE_...`: no es igual al wrapper de producción con scratch/rsync/resume.
- `modelos/starobinsky.py`: implementa las relaciones matemáticas, **no sustituye automáticamente** al módulo Cobaya `effective.py` de producción.
- `environment/environment-sugerido.yml`: entorno sugerido; **no** es un `conda env export` de 2026.

## Dónde están los archivos originales (inventario histórico)

**Bajo `~/Yaml`**:

- `effective.py`
- `polychord_starobinsky_SR1.yaml`, `polychord_starobinsky_SR2.yaml`, `polychord_starobinsky_SR2_reh.yaml`
- `polychord_starobinsky_N50.yaml`, `_N60.yaml`, `_Nfree.yaml`
- `mcmc_starobinsky_effective_SR1.yaml`, `mcmc_starobinsky_effective_SR2.yaml`, `mcmc_starobinsky_fenomenologico.yaml`
- `polychord_starobinsky_SR1_test30.yaml`, `run_polychord_SR1_test30.slurm`, `run_polychord_SR1_test30_resume.slurm`
- `comprobar_dependencia_starobinsky.py`
- `def/` con reference LCDM+r y ensayos antiguos.

**Bajo `~/Yaml/final`**:

- `polychord_starobinsky_SR1.yaml`, `run_polychord_SR1.slurm`, `run_polychord_SR1_resume.slurm`
- `chains_SR1_300/` y logs `SR1_300_15453.out`, `SR1_300_resume_16729.out` (históricos).

**Bajo `~/Yaml/final/Datos`**:

- `codigos_tesis_corregidos/`, `ml_final/`, `pytorch_resultados_tesis_nuevos/`
- `graficos_finales/`, `Resultados/`
- `grafin_publicable_getdist_verde.py`, `pytorch_tesis.py`, `tesis_chain_utils.py`, `validar_emulador_cobaya.py`, `ml_final_tesis.py`.

**Otras ubicaciones**: otra cuenta usó `~/final` para SR2 MPI (p.ej. `run_polychord_SR2_MPI_seguro.slurm`, `chains_SR2_300_MPI`). El importador local no obtiene contenido de cuentas ajenas. Solicitar a sus dueños una copia autorizada si fuera necesaria.

## Plan para completar 100% fielmente

1. Exportar originales desde **la cuenta que los posee** usando [`scripts/importar_originales_hpc.sh`](../scripts/importar_originales_hpc.sh).
2. Conservar nombre, rutas relativas, checksums y versiones. Comparar archivos SR1/SR2/LCDM+r de producción contra los ejemplos de documentación. Tras revisar secretos/licencias, agregar con `git add -f originales_hpc/<rutas-validadas>` porque ese directorio está ignorado por precaución.
3. Ejecutar `cobaya-run ... --test` dentro de Enroot/Conda y guardar logs de inicialización.
4. Guardar `conda env export` y `pip freeze` históricos, registrar versión de CLASS, PolyChord y Cobaya.
5. Separar chain data enormes/licenciados de Git; empaquetar resultados autorizados con checksums y depositar en almacenamiento externo apropiado si se desean publicar.
6. Revisar privacidad, licencias de software/datos y permisos institucionales antes de poner el GitHub público.

No se han recuperado los bytes originales de YAML, `.slurm`, `effective.py` ni cadenas a través de GitHub o el clúster en este turno. Nunca se deben presentar los archivos de ejemplo como registros exactos de producción.
