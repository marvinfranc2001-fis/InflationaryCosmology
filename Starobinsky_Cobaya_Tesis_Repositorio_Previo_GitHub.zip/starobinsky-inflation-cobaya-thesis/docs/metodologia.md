# Metodología científica y parámetros

Fuentes: manuscrito *Study of the Starobinsky Inflationary Model Using the Cobaya Code*, capítulos 3–5, especialmente §4.3–4.9 y tablas 4.1, 5.2–5.3. Son **fórmulas reportadas en la tesis**, no códigos extraídos de `effective.py`.

## Modelos

1. **Referencia ΛCDM + r**: `n_s` y `r_0.05` se muestrean libremente.
2. **SR1**: `N_*` se muestrea, y se calculan las cantidades primordiales de primer orden según las expresiones efectivamente usadas en la tesis.
3. **SR2**: se muestrea el mismo `N_*`, con correcciones de segundo orden; los otros parámetros, priors y likelihoods se preservan.

En los tres modelos, el pivote es `k_* = 0.05 Mpc^-1` y se usan modos escalares y tensoriales.

**Relaciones exactas utilizadas en la tesis:**

SR1:

- `n_s = 1 - 2/N_* - 9/(2 N_*^2)`
- `r_0.05 = 12/N_*^2`
- `alpha_s = 0`

SR2:

- `n_s = 1 - 2/N_* - 3/(2 N_*^2)`
- `r_0.05 = (12/N_*^2) * (1 - 2/N_*)`
- `alpha_s = -2/N_*^2 - 3/N_*^3`

Escalar primitivo:

`ln P_R(k) = ln(A_s) + (n_s - 1) ln(k/k_*) + (alpha_s/2) [ln(k/k_*)]^2`

`alpha_s` no se muestrea independientemente en SR2. SR1 la fija a cero. Los observables `n_s`, `r_0.05` y `alpha_s` se derivan de `N_*` en SR1 y SR2.

## Priors uniformes (tabla 4.1)

| Parámetro | Min | Max |
| --- | ---: | ---: |
| `N_*` | 50 | 60 |
| `A_s` | 1.8e-9 | 3.0e-9 |
| `H0` | 60 | 75 |
| `omega_b` | 0.020 | 0.024 |
| `omega_cdm` | 0.10 | 0.14 |
| `tau_reio` | 0.04 | 0.08 |

Referencia ΛCDM+r: igual base, más `0.94 <= n_s <= 0.99` y `0 <= r_0.05 <= 0.08`; `N_*` no forma parte de la referencia. Los parámetros nuisance de calibración de Planck y foregrounds de BICEP/Keck son comunes.

## Likelihoods (combinación PolyChord definitiva)

```yaml
likelihood:
  planck_2018_lowl.TT: null
  planck_2018_lowl.EE: null
  planck_2018_highl_plik.TTTEEE_lite: null
  bicep_keck_2018: null
```

**Diferencia importante:** las cadenas MCMC usaron `planck_2018_highl_plik.TTTEEE_lite_native`, mientras la comparación final con PolyChord usó `planck_2018_highl_plik.TTTEEE_lite`. Por eso los valores absolutos de χ² entre estos dos tipos de corridas no se deben combinar directamente.

No se añadió la verosimilitud de reconstrucción de lensing de Planck como dataset independiente en la comparación principal.

## Samplers

- MCMC de Cobaya: comprobación de parámetros y convergencia `R-1 < 0.01`; burn-in de 30% en el cotejo MCMC–PolyChord.
- PolyChord nested sampling: `nlive = 300` para referencia, SR1 y SR2; **`num_repeats=25` se recuperó de los registros de configuración históricos**, pero la copia exacta del YAML original está pendiente.
- Comparación primaria homogénea nlive 300; el ensayo exploratorio LCDM+r con 1000 live points **no se incorpora a la comparación final**.

## Machine learning (complementario)

Clasificación logística, random forest, validación cruzada, ablation de parámetros, importancia, SHAP, PCA/UMAP, ensambles neuronales locales para χ² total/parcial, aprendizaje activo y validación externa con evaluaciones nuevas Cobaya + CLASS. Los emuladores **NO** sustituyen el cálculo de evidencia ni son la fuente de los resultados cosmológicos definitivos.
