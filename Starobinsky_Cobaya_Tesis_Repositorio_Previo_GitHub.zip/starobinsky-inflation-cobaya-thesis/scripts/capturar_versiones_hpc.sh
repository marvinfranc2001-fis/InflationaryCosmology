#!/usr/bin/env bash
# Ejecutar SOLO dentro del entorno Conda activo en nodo permitido.
set -euo pipefail
DIR="${1:-versiones_entorno}"
mkdir -p "$DIR"
python --version > "$DIR/python-version.txt" 2>&1
python -m pip freeze > "$DIR/pip-freeze.txt"
if command -v conda >/dev/null 2>&1; then
  conda env export --no-builds > "$DIR/conda-env-sin-builds.yml" || true
fi
for c in mpirun mpicc mpif90; do { command -v "$c" || true; } >> "$DIR/herramientas.txt"; done
# Revisar archivos antes de compartir (posibles rutas/URLs internas en exports).
echo "Versiones guardadas en $DIR; revísalas antes de subir."
