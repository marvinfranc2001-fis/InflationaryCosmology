#!/usr/bin/env bash
# Ejecutar SOLO DESPUÉS de crear un repositorio PRIVADO vacío en GitHub
# y conceder acceso a la integración GitHub para permitir su uso por ChatGPT.
set -euo pipefail
REPO="${1:-marvinfranc2001-fis/starobinsky-inflation-cobaya-thesis}"
if [[ "$REPO" != */* ]]; then echo 'Usa propietario/nombre'; exit 2; fi
[[ -d .git ]] || git init -b main
if ! git remote get-url origin >/dev/null 2>&1; then
  git remote add origin "https://github.com/${REPO}.git"
fi
git add README.md docs environment modelos tests scripts slurm configs_reconstruidas machine_learning resultados .gitignore .gitattributes PACKAGE_MANIFEST.json
if [[ -d originales_hpc ]]; then
  echo 'Los originales existen: revisar privacidad y añadirlos manualmente con git add -f originales_hpc/ después de su inspección.'
fi
git status --short
printf '\nRevisa el estado y ejecuta cuando estés listo:\n'
printf 'git commit -m "Document thesis computational workflow"\ngit push -u origin main\n'
