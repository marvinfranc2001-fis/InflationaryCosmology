#!/usr/bin/env bash
set -euo pipefail
printf '%s\n' '=== Node / SLURM ==='
hostname || true
printf 'SLURM_JOB_ID=%s\n' "${SLURM_JOB_ID:-sin_asignacion}"
printf '%s\n' '=== Commands ==='
for command_name in python cobaya-run conda mpicc mpif90 enroot; do
    command -v "$command_name" || true
done
printf '%s\n' '=== Versions and imports ==='
python --version
python - <<'PYCODE'
for name in ('cobaya','classy','pypolychord','mpi4py','numpy'):
    try:
        module=__import__(name)
        print(name, 'OK', getattr(module,'__version__','sin __version__'))
    except Exception as exc:
        print(name,'FAIL',type(exc).__name__,str(exc))
PYCODE
