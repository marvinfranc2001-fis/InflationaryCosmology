#!/usr/bin/env bash
# Ejecutar desde la raíz del checkout Git, EN el clúster y la cuenta propia.
# Sólo copia archivos legibles del árbol ~/Yaml, sin conexiones de red.
set -euo pipefail
WITH_RESULTS=0
[[ "${1:-}" == "--resultados" ]] && WITH_RESULTS=1
SOURCE="${TESIS_HPC_SOURCE:-$HOME/Yaml}"
if [[ ! -d "$SOURCE" ]]; then
    echo "No existe $SOURCE. Define TESIS_HPC_SOURCE=/ruta/Yaml" >&2
    exit 1
fi
if [[ ! -f README.md || ! -d docs ]]; then
    echo 'Ejecuta desde la raíz del repositorio preparado.' >&2
    exit 1
fi
DST="$PWD/originales_hpc"
mkdir -p "$DST"
COUNT=0
while IFS= read -r -d '' f; do
    rel="${f#$SOURCE/}"
    # La preservación de rutas evita colisiones entre Yaml y Yaml/final.
    mkdir -p "$DST/$(dirname "$rel")"
    cp -p "$f" "$DST/$rel"
    COUNT=$((COUNT+1))
done < <(find "$SOURCE" -type f \(
    -iname '*.yaml' -o -iname '*.yml' -o -iname '*.slurm' -o
    -iname '*.py' -o -iname '*.sh' -o -iname '*.ipynb' -o
    -iname '*.toml' -o -iname '*.cfg' -o -iname '*.tex' \)
    ! -path '*/__pycache__/*' ! -path '*/.git/*' ! -path '*/.ssh/*'
    ! -path '*/miniconda3/*' -print0)
echo "Copiados $COUNT archivos fuente a originales_hpc/"
if [[ "$WITH_RESULTS" -eq 1 ]]; then
    DATA="$PWD/resultados_locales"
    mkdir -p "$DATA"
    # Solo resultados legibles, no archivos temporales gigantes automáticos.
    find "$SOURCE" -type f \( -name '*.paramnames' -o -name '*_equal_weights.txt' -o
      -name '*.stats' -o -name '*.progress' -o -name '*.minimum' \) -print0 |
    while IFS= read -r -d '' f; do
      rel="${f#$SOURCE/}"
      mkdir -p "$DATA/$(dirname "$rel")"
      cp -p "$f" "$DATA/$rel"
    done
    echo 'Resultados bajo resultados_locales/ (excluidos de Git).'
fi
printf 'Inventario y SHA256 de fuentes copiadas:\n'
find "$DST" -type f -print0 | sort -z | xargs -0 -r sha256sum > "$PWD/MANIFEST_ORIGINALES_SHA256.txt"
echo 'Revisar MANIFEST_ORIGINALES_SHA256.txt para trazabilidad.'
