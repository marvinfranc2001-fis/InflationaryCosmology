#!/usr/bin/env python3
"""Pruebas independientes de datos, Cobaya, CLASS y PolyChord."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from modelos.starobinsky import sr1, sr2
for n in (50.0,55.0,60.0):
    print(f'N*={n:.0f}: SR1={sr1(n)} SR2={sr2(n)}')
try:
    import yaml
except ImportError:
    print('PyYAML no disponible: se omitió el parseo de los YAML de ejemplo')
else:
    from pathlib import Path
    for path in sorted(Path('configs_reconstruidas').glob('*.yaml')):
        obj=yaml.safe_load(path.read_text())
        assert 'likelihood' in obj and 'theory' in obj and 'sampler' in obj, path
        print('YAML parseable:', path)
print('Comprobación local de estructura terminada (NO equivale a un test cosmológico).')
