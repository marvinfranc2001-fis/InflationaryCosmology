import unittest
from modelos.starobinsky import sr1, sr2, primordial_scalar_power

class TestObservables(unittest.TestCase):
    def test_sr1_at_55(self):
        out = sr1(55)
        self.assertAlmostEqual(out.n_s, 1-2/55-9/(2*55**2))
        self.assertAlmostEqual(out.r_005, 12/55**2)
        self.assertEqual(out.alpha_s, 0)

    def test_sr2_at_55(self):
        out = sr2(55)
        self.assertAlmostEqual(out.n_s, 1-2/55-3/(2*55**2))
        self.assertAlmostEqual(out.r_005, (12/55**2)*(1-2/55))
        self.assertAlmostEqual(out.alpha_s, -2/55**2-3/55**3)
        self.assertLess(out.r_005, sr1(55).r_005)

    def test_pivot_spectrum(self):
        self.assertAlmostEqual(primordial_scalar_power(0.05,2.1e-9,0.965,-0.0007),2.1e-9)

    def test_invalid_N(self):
        with self.assertRaises(ValueError):
            sr1(0)
        with self.assertRaises(ValueError):
            sr2(-4)

if __name__ == '__main__':
    unittest.main()
