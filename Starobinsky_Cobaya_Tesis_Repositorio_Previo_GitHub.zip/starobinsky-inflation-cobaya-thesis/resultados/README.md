# Resultados científicos (documentados, no recalculados)

Los siguientes números proceden de tablas 5.2 y 5.3 de la tesis 2026, no de un job lanzado al preparar este repositorio.

| Modelo | ln(Z) | sigma_ln(Z) |
| --- | ---: | ---: |
| LCDM+r | -797.3157 | 0.2742 |
| SR1 | -795.3275 | 0.2655 |
| SR2 | -794.4122 | 0.2636 |

| Comparación | delta_ln(Z) | sigma | factor de Bayes (aprox.) |
| --- | ---: | ---: | ---: |
| SR1 vs LCDM+r | 1.9882 | 0.3816 | 7.30 |
| SR2 vs LCDM+r | 2.9036 | 0.3803 | 18.24 |
| SR2 vs SR1 | 0.9154 | 0.3741 | 2.50 |

Conclusión documentada: el modelo SR2 obtuvo la mayor evidencia central, pero la preferencia sobre SR1 fue débil; ambas implementaciones fueron favorecidas respecto a la referencia fenomenológica bajo los supuestos de este análisis.

No guardar en Git cadenas gigantes automáticamente. Los resultados finales originales se hallaban, entre otras rutas, en `~/Yaml/final/chains_SR1_300/` y en directorios de SR2. Mantener hashes SHA256 y una tabla que vincule cada `output:` a su YAML y job SLURM exactos antes de depositar datos abiertos.
