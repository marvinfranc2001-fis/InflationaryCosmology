# YAML de ejemplo — verificar contra los originales

**Estos YAML se reconstruyeron a partir de las ecuaciones y priors del manuscrito y las prácticas históricas descritas. No son una exportación de los seis YAML originales usados en tesis.** Aun si llegan a superar `cobaya-run --test`, esto no prueba equivalencia de likelihoods ni de los ajustes de nuisance, convergencia, clases Theory personalizadas, versiones de CLASS o salidas finales.

- `polychord_SR1.example.yaml`, `polychord_SR2.example.yaml`, `polychord_LCDM_r.example.yaml`: combinación high-ell TTTEEE_lite usada para la comparación de evidencia.
- `mcmc_SR1.example.yaml`, `mcmc_SR2.example.yaml`, `mcmc_LCDM_r.example.yaml`: variante high-ell `...TTTEEE_lite_native` documentada para cadenas MCMC; la referencia MCMC es solo un ejemplo didáctico.
- Las clases originales `effective.EffectiveStarobinsky_SR1/SR2` no están incrustadas aquí: los YAML de ejemplo sustituyen matemáticamente las observables por `lambda` en el bloque de parámetros. **Validar la correspondencia de las claves CLASS, los nombres de parámetros nuisance y las versiones exactas antes de ejecutar.**

### Prioridad

El código confiable para reproducción histórica estará en `originales_hpc/` después de ejecutar el importador en la cuenta CEDIA. **No utilizar la evidencia extraída de estos ejemplos como valor de la tesis.**
